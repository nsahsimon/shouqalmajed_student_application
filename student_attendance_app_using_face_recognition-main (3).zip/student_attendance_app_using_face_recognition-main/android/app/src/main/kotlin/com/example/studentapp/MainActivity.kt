package com.example.studentapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
