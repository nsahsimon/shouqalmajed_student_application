import 'package:studentapp/models/user_data.dart';

late UserData myUserData;

